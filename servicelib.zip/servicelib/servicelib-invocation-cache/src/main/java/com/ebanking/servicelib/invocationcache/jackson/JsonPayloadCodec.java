package com.ebanking.servicelib.invocationcache.jackson;

import java.io.IOException;
import java.util.Objects;
import com.ebanking.servicelib.invocationcache.exception.InvocationCacheSerializationException;
import com.ebanking.servicelib.invocationcache.model.PayloadCodec;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class JsonPayloadCodec<T> implements PayloadCodec<T> {
    private final ObjectMapper objectMapper;
    public JsonPayloadCodec(ObjectMapper objectMapper) { this.objectMapper = Objects.requireNonNull(objectMapper, "objectMapper"); }
    @Override public String name() { return "json"; }
    @Override public byte[] serialize(T value) {
        try { return objectMapper.writeValueAsBytes(value); }
        catch (IOException e) { throw new InvocationCacheSerializationException("Could not serialize invocation cache payload", e); }
    }
    @Override public T deserialize(byte[] payload, Class<T> type) {
        try { return objectMapper.readValue(payload, type); }
        catch (IOException e) { throw new InvocationCacheSerializationException("Could not deserialize invocation cache payload as " + type.getName(), e); }
    }
}
