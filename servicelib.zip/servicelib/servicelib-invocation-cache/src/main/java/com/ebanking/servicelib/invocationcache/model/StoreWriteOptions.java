package com.ebanking.servicelib.invocationcache.model;

import java.time.Duration;
import java.util.Objects;

public record StoreWriteOptions(Duration physicalTtl) {
    public StoreWriteOptions {
        Objects.requireNonNull(physicalTtl, "physicalTtl");
        if (physicalTtl.isZero() || physicalTtl.isNegative()) throw new IllegalArgumentException("physicalTtl must be positive");
    }
}
