package com.ebanking.servicelib.invocationcache.jackson;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Objects;
import com.ebanking.servicelib.invocationcache.exception.InvocationCacheSerializationException;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class JsonSha256InvocationArgumentsHasher {
    private final ObjectMapper objectMapper;
    public JsonSha256InvocationArgumentsHasher(ObjectMapper objectMapper) { this.objectMapper = Objects.requireNonNull(objectMapper, "objectMapper"); }
    public String hash(Object arguments) {
        try {
            var json = objectMapper.writeValueAsBytes(arguments);
            var digest = MessageDigest.getInstance("SHA-256").digest(json);
            return HexFormat.of().formatHex(digest);
        } catch (IOException e) { throw new InvocationCacheSerializationException("Could not serialize invocation arguments for hashing", e); }
        catch (NoSuchAlgorithmException e) { throw new IllegalStateException("SHA-256 is not available", e); }
    }
}
