package com.ebanking.servicelib.invocationcache;

import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import com.ebanking.servicelib.invocationcache.model.StoreWriteOptions;
import com.ebanking.servicelib.invocationcache.model.StoredInvocationCacheEntry;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;

public final class HazelcastInvocationCacheStore implements InvocationCacheStore {
    public static final String DEFAULT_MAP_NAME = "invocation.cache";
    private final IMap<String, StoredInvocationCacheEntry> map;
    public HazelcastInvocationCacheStore(HazelcastInstance hazelcastInstance) { this(hazelcastInstance, DEFAULT_MAP_NAME); }
    public HazelcastInvocationCacheStore(HazelcastInstance hazelcastInstance, String mapName) {
        Objects.requireNonNull(hazelcastInstance, "hazelcastInstance");
        Objects.requireNonNull(mapName, "mapName");
        if (mapName.isBlank()) throw new IllegalArgumentException("mapName must not be blank");
        this.map = hazelcastInstance.getMap(mapName);
    }
    @Override public void put(String storeKey, StoredInvocationCacheEntry entry, StoreWriteOptions options) { map.set(storeKey, entry, options.physicalTtl().toMillis(), TimeUnit.MILLISECONDS); }
    @Override public Optional<StoredInvocationCacheEntry> get(String storeKey) { return Optional.ofNullable(map.get(storeKey)); }
    @Override public void remove(String storeKey) { map.remove(storeKey); }
    @Override public void removeByPrefix(String prefix) { for (String key : map.keySet()) if (key.startsWith(prefix)) map.remove(key); }
}
