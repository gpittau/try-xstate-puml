package com.ebanking.servicelib.invocationcache.model;

public interface PayloadCodec<T> { String name(); byte[] serialize(T value); T deserialize(byte[] payload, Class<T> type); }
