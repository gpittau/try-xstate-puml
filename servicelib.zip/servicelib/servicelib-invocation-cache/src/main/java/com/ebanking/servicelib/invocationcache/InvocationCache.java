package com.ebanking.servicelib.invocationcache;

import java.util.Optional;
import java.util.function.Supplier;
import com.ebanking.servicelib.invocationcache.model.CacheScope;
import com.ebanking.servicelib.invocationcache.model.InvocationCacheDescriptor;
import com.ebanking.servicelib.invocationcache.model.InvocationCacheKey;

public interface InvocationCache {
    <T> Optional<T> get(InvocationCacheKey key, InvocationCacheDescriptor<T> descriptor);
    <T> void put(InvocationCacheKey key, InvocationCacheDescriptor<T> descriptor, T value);
    <T> T getOrCompute(InvocationCacheKey key, InvocationCacheDescriptor<T> descriptor, Supplier<? extends T> supplier);
    void evict(InvocationCacheKey key);
    void evictScope(CacheScope scope);
}
