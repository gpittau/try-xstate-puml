package com.ebanking.servicelib.invocationcache.model;

public record GlobalCacheScope() implements CacheScope {
    @Override public CacheScopeKind kind() { return CacheScopeKind.GLOBAL; }
    @Override public String value() { return "global"; }
}
