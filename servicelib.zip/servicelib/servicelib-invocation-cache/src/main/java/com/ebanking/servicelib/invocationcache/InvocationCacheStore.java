package com.ebanking.servicelib.invocationcache;

import java.util.Optional;
import com.ebanking.servicelib.invocationcache.model.StoreWriteOptions;
import com.ebanking.servicelib.invocationcache.model.StoredInvocationCacheEntry;

public interface InvocationCacheStore {
    void put(String storeKey, StoredInvocationCacheEntry entry, StoreWriteOptions options);
    Optional<StoredInvocationCacheEntry> get(String storeKey);
    void remove(String storeKey);
    void removeByPrefix(String prefix);
}
