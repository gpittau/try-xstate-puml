package com.ebanking.servicelib.invocationcache.model;

import java.util.Objects;

public record InvocationCacheKey(CacheScope scope, String operationName, String argumentsHash) {
    public InvocationCacheKey {
        Objects.requireNonNull(scope, "scope");
        Objects.requireNonNull(operationName, "operationName");
        Objects.requireNonNull(argumentsHash, "argumentsHash");
        if (operationName.isBlank()) throw new IllegalArgumentException("operationName must not be blank");
        if (argumentsHash.isBlank()) throw new IllegalArgumentException("argumentsHash must not be blank");
    }
    public String asStoreKey() { return scopePrefix() + "operation:" + operationName + ":args:" + argumentsHash; }
    public String scopePrefix() { return "scope:" + scope.asKeyPart() + ":"; }
}
