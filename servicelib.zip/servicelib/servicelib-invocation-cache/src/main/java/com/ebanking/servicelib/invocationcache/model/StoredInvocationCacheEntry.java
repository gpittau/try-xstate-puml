package com.ebanking.servicelib.invocationcache.model;

import java.io.Serial;
import java.io.Serializable;
import java.time.Instant;
import java.util.Arrays;
import java.util.Objects;

public record StoredInvocationCacheEntry(String storeKey, CacheScopeKind scopeKind, String scopeValue, String descriptorName, String javaType, int schemaVersion, String codec, byte[] payload, Instant storedAt, Instant expiresAt) implements Serializable {
    @Serial private static final long serialVersionUID = 1L;
    public StoredInvocationCacheEntry {
        Objects.requireNonNull(storeKey, "storeKey");
        Objects.requireNonNull(scopeKind, "scopeKind");
        Objects.requireNonNull(scopeValue, "scopeValue");
        Objects.requireNonNull(descriptorName, "descriptorName");
        Objects.requireNonNull(javaType, "javaType");
        Objects.requireNonNull(codec, "codec");
        Objects.requireNonNull(payload, "payload");
        Objects.requireNonNull(storedAt, "storedAt");
        Objects.requireNonNull(expiresAt, "expiresAt");
        payload = Arrays.copyOf(payload, payload.length);
    }
    @Override public byte[] payload() { return Arrays.copyOf(payload, payload.length); }
    public boolean isExpiredAt(Instant now) { return !now.isBefore(expiresAt); }
}
