package com.ebanking.servicelib.invocationcache.metrics;

import com.ebanking.servicelib.invocationcache.model.InvocationCacheKey;

public final class NoOpInvocationCacheMetrics implements InvocationCacheMetrics {
    @Override public void hit(InvocationCacheKey key) {}
    @Override public void miss(InvocationCacheKey key) {}
    @Override public void put(InvocationCacheKey key, int payloadBytes) {}
    @Override public void evict(InvocationCacheKey key) {}
    @Override public void evictScope(String scopePrefix) {}
}
