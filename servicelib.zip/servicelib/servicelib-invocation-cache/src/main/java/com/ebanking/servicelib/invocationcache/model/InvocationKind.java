package com.ebanking.servicelib.invocationcache.model;

public enum InvocationKind { QUERY, COMMAND }
