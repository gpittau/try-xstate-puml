package com.ebanking.servicelib.invocationcache.exception;

public class InvocationCacheException extends RuntimeException {
    public InvocationCacheException(String message) { super(message); }
    public InvocationCacheException(String message, Throwable cause) { super(message, cause); }
}
