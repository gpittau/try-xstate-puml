package com.ebanking.servicelib.invocationcache.model;

public enum CacheScopeKind { SESSION, USER, GLOBAL }
