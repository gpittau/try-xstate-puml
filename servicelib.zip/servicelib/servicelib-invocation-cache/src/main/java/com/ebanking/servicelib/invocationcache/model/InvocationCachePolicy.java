package com.ebanking.servicelib.invocationcache.model;

import java.time.Duration;
import java.util.Objects;

public record InvocationCachePolicy(InvocationKind invocationKind, Duration ttl, Duration physicalRetentionAfterExpiration, int maxBytes, boolean cacheNulls, boolean cacheBusinessErrors, boolean cacheTechnicalErrors) {
    public InvocationCachePolicy {
        Objects.requireNonNull(invocationKind, "invocationKind");
        Objects.requireNonNull(ttl, "ttl");
        Objects.requireNonNull(physicalRetentionAfterExpiration, "physicalRetentionAfterExpiration");
        if (invocationKind == InvocationKind.COMMAND) throw new IllegalArgumentException("COMMAND invocations are not cacheable by default");
        if (ttl.isZero() || ttl.isNegative()) throw new IllegalArgumentException("ttl must be positive");
        if (physicalRetentionAfterExpiration.isNegative()) throw new IllegalArgumentException("physicalRetentionAfterExpiration must not be negative");
        if (maxBytes <= 0) throw new IllegalArgumentException("maxBytes must be positive");
        if (cacheTechnicalErrors) throw new IllegalArgumentException("technical errors must not be cached by default");
    }
    public static InvocationCachePolicy query(Duration ttl, int maxBytes) { return new InvocationCachePolicy(InvocationKind.QUERY, ttl, Duration.ZERO, maxBytes, false, false, false); }
    public InvocationCachePolicy withPhysicalRetentionAfterExpiration(Duration retention) { return new InvocationCachePolicy(invocationKind, ttl, retention, maxBytes, cacheNulls, cacheBusinessErrors, cacheTechnicalErrors); }
}
