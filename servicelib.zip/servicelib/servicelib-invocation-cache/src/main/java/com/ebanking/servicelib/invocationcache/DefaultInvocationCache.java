package com.ebanking.servicelib.invocationcache;

import java.time.Clock;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;
import com.ebanking.servicelib.invocationcache.exception.InvocationCachePayloadTooLargeException;
import com.ebanking.servicelib.invocationcache.metrics.InvocationCacheMetrics;
import com.ebanking.servicelib.invocationcache.model.CacheScope;
import com.ebanking.servicelib.invocationcache.model.InvocationCacheDescriptor;
import com.ebanking.servicelib.invocationcache.model.InvocationCacheKey;
import com.ebanking.servicelib.invocationcache.model.StoreWriteOptions;
import com.ebanking.servicelib.invocationcache.model.StoredInvocationCacheEntry;

public final class DefaultInvocationCache implements InvocationCache {
    private final InvocationCacheStore store;
    private final Clock clock;
    private final InvocationCacheMetrics metrics;
    public DefaultInvocationCache(InvocationCacheStore store, Clock clock, InvocationCacheMetrics metrics) {
        this.store = Objects.requireNonNull(store, "store");
        this.clock = Objects.requireNonNull(clock, "clock");
        this.metrics = Objects.requireNonNull(metrics, "metrics");
    }
    @Override public <T> Optional<T> get(InvocationCacheKey key, InvocationCacheDescriptor<T> descriptor) {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(descriptor, "descriptor");
        var storeKey = key.asStoreKey();
        var stored = store.get(storeKey);
        if (stored.isEmpty()) { metrics.miss(key); return Optional.empty(); }
        var entry = stored.orElseThrow();
        var now = clock.instant();
        if (entry.isExpiredAt(now)) { store.remove(storeKey); metrics.miss(key); return Optional.empty(); }
        if (entry.schemaVersion() != descriptor.schemaVersion()) { store.remove(storeKey); metrics.miss(key); return Optional.empty(); }
        var value = descriptor.codec().deserialize(entry.payload(), descriptor.type());
        metrics.hit(key);
        return Optional.ofNullable(value);
    }
    @Override public <T> void put(InvocationCacheKey key, InvocationCacheDescriptor<T> descriptor, T value) {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(descriptor, "descriptor");
        if (value == null && !descriptor.policy().cacheNulls()) return;
        var payload = descriptor.codec().serialize(value);
        if (payload.length > descriptor.policy().maxBytes()) throw new InvocationCachePayloadTooLargeException(descriptor.name(), payload.length, descriptor.policy().maxBytes());
        var now = clock.instant();
        var expiresAt = now.plus(descriptor.policy().ttl());
        var physicalTtl = descriptor.policy().ttl().plus(descriptor.policy().physicalRetentionAfterExpiration());
        var entry = new StoredInvocationCacheEntry(key.asStoreKey(), key.scope().kind(), key.scope().value(), descriptor.name(), descriptor.type().getName(), descriptor.schemaVersion(), descriptor.codec().name(), payload, now, expiresAt);
        store.put(key.asStoreKey(), entry, new StoreWriteOptions(physicalTtl));
        metrics.put(key, payload.length);
    }
    @Override public <T> T getOrCompute(InvocationCacheKey key, InvocationCacheDescriptor<T> descriptor, Supplier<? extends T> supplier) {
        Objects.requireNonNull(supplier, "supplier");
        var cached = get(key, descriptor);
        if (cached.isPresent()) return cached.orElseThrow();
        var value = supplier.get();
        put(key, descriptor, value);
        return value;
    }
    @Override public void evict(InvocationCacheKey key) {
        Objects.requireNonNull(key, "key");
        store.remove(key.asStoreKey());
        metrics.evict(key);
    }
    @Override public void evictScope(CacheScope scope) {
        Objects.requireNonNull(scope, "scope");
        var prefix = "scope:" + scope.asKeyPart() + ":";
        store.removeByPrefix(prefix);
        metrics.evictScope(prefix);
    }
}
