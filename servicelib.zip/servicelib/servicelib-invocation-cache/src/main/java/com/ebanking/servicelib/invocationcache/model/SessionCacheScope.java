package com.ebanking.servicelib.invocationcache.model;

import java.util.Objects;

public record SessionCacheScope(String sessionId) implements CacheScope {
    public SessionCacheScope { Objects.requireNonNull(sessionId, "sessionId"); if (sessionId.isBlank()) throw new IllegalArgumentException("sessionId must not be blank"); }
    @Override public CacheScopeKind kind() { return CacheScopeKind.SESSION; }
    @Override public String value() { return sessionId; }
}
