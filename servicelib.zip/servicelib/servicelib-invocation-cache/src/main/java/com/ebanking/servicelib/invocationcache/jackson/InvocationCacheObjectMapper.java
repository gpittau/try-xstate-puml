package com.ebanking.servicelib.invocationcache.jackson;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

public final class InvocationCacheObjectMapper {
    private InvocationCacheObjectMapper() {}
    public static ObjectMapper create() {
        return new ObjectMapper().registerModule(new Jdk8Module()).registerModule(new JavaTimeModule()).configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, true).configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true).disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }
}
