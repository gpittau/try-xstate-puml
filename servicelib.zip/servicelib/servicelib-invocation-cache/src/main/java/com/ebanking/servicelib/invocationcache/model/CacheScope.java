package com.ebanking.servicelib.invocationcache.model;

public sealed interface CacheScope permits SessionCacheScope, UserCacheScope, GlobalCacheScope {
    CacheScopeKind kind();
    String value();
    default String asKeyPart() {
        return switch (this) {
            case SessionCacheScope scope -> "session:" + scope.sessionId();
            case UserCacheScope scope -> "user:" + scope.userId();
            case GlobalCacheScope ignored -> "global";
        };
    }
}
