package com.ebanking.servicelib.invocationcache.model;

import java.util.Objects;

public record InvocationCacheDescriptor<T>(String name, Class<T> type, int schemaVersion, PayloadCodec<T> codec, InvocationCachePolicy policy) {
    public InvocationCacheDescriptor {
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(codec, "codec");
        Objects.requireNonNull(policy, "policy");
        if (name.isBlank()) throw new IllegalArgumentException("name must not be blank");
        if (schemaVersion <= 0) throw new IllegalArgumentException("schemaVersion must be positive");
    }
}
