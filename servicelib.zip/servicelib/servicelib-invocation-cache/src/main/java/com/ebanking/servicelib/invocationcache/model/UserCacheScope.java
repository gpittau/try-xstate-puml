package com.ebanking.servicelib.invocationcache.model;

import java.util.Objects;

public record UserCacheScope(String userId) implements CacheScope {
    public UserCacheScope { Objects.requireNonNull(userId, "userId"); if (userId.isBlank()) throw new IllegalArgumentException("userId must not be blank"); }
    @Override public CacheScopeKind kind() { return CacheScopeKind.USER; }
    @Override public String value() { return userId; }
}
