package com.ebanking.servicelib.invocationcache.exception;

public final class InvocationCachePayloadTooLargeException extends InvocationCacheException {
    public InvocationCachePayloadTooLargeException(String descriptorName, int actualBytes, int maxBytes) {
        super("Payload too large for invocation cache descriptor '%s'. Actual: %d bytes, max: %d bytes".formatted(descriptorName, actualBytes, maxBytes));
    }
}
