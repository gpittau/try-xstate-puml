package com.ebanking.servicelib.invocationcache.exception;

public final class InvocationCacheSerializationException extends InvocationCacheException {
    public InvocationCacheSerializationException(String message, Throwable cause) { super(message, cause); }
}
