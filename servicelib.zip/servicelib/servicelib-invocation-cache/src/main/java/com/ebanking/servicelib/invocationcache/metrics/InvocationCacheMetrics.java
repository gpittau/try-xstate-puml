package com.ebanking.servicelib.invocationcache.metrics;

import com.ebanking.servicelib.invocationcache.model.InvocationCacheKey;

public interface InvocationCacheMetrics {
    void hit(InvocationCacheKey key);
    void miss(InvocationCacheKey key);
    void put(InvocationCacheKey key, int payloadBytes);
    void evict(InvocationCacheKey key);
    void evictScope(String scopePrefix);
}
