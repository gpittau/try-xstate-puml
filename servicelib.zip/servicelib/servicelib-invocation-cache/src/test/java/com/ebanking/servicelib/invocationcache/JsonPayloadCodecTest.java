package com.ebanking.servicelib.invocationcache;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import com.ebanking.servicelib.invocationcache.jackson.InvocationCacheObjectMapper;
import com.ebanking.servicelib.invocationcache.jackson.JsonPayloadCodec;

final class JsonPayloadCodecTest {
    @Test void serializesAndDeserializesRecord() {
        var codec = new JsonPayloadCodec<TestResponse>(InvocationCacheObjectMapper.create());
        var value = new TestResponse("0", "ok");
        assertEquals(value, codec.deserialize(codec.serialize(value), TestResponse.class));
    }
}
