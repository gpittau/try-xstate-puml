package com.ebanking.servicelib.invocationcache;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import com.ebanking.servicelib.invocationcache.jackson.InvocationCacheObjectMapper;
import com.ebanking.servicelib.invocationcache.jackson.JsonSha256InvocationArgumentsHasher;

final class JsonSha256InvocationArgumentsHasherTest {
    @Test void producesSameHashForSameArguments() {
        var hasher = new JsonSha256InvocationArgumentsHasher(InvocationCacheObjectMapper.create());
        assertEquals(hasher.hash(new Arguments("c-1", 10)), hasher.hash(new Arguments("c-1", 10)));
    }
    private record Arguments(String clientId, int limit) {}
}
