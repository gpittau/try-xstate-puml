package com.ebanking.servicelib.invocationcache;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Objects;

public final class MutableClock extends Clock {
    private Instant instant;
    private final ZoneId zone;
    public MutableClock(Instant instant, ZoneId zone) { this.instant = Objects.requireNonNull(instant, "instant"); this.zone = Objects.requireNonNull(zone, "zone"); }
    public static MutableClock utc(Instant instant) { return new MutableClock(instant, ZoneId.of("UTC")); }
    public void advance(Duration duration) { instant = instant.plus(duration); }
    @Override public ZoneId getZone() { return zone; }
    @Override public Clock withZone(ZoneId zone) { return new MutableClock(instant, zone); }
    @Override public Instant instant() { return instant; }
}
