package com.ebanking.servicelib.invocationcache;

import static org.junit.jupiter.api.Assertions.assertTrue;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.ebanking.servicelib.invocationcache.model.CacheScopeKind;
import com.ebanking.servicelib.invocationcache.model.StoreWriteOptions;
import com.ebanking.servicelib.invocationcache.model.StoredInvocationCacheEntry;
import com.hazelcast.config.Config;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;

final class HazelcastInvocationCacheStoreIT {
    private HazelcastInstance hazelcast;
    private HazelcastInvocationCacheStore store;
    @BeforeEach void setUp() {
        var config = new Config();
        config.setClusterName("servicelib-invocation-cache-test-" + UUID.randomUUID());
        config.getNetworkConfig().getJoin().getMulticastConfig().setEnabled(false);
        config.getNetworkConfig().getJoin().getTcpIpConfig().setEnabled(false);
        hazelcast = Hazelcast.newHazelcastInstance(config);
        store = new HazelcastInvocationCacheStore(hazelcast);
    }
    @AfterEach void tearDown() { hazelcast.shutdown(); }
    @Test void putGetRemoveWorksWithEmbeddedHazelcast() {
        var key = "scope:session:s-1:operation:Service.method:args:abc";
        store.put(key, entry(key, Instant.parse("2026-05-17T12:05:00Z")), new StoreWriteOptions(Duration.ofMinutes(1)));
        assertTrue(store.get(key).isPresent());
        store.remove(key);
        assertTrue(store.get(key).isEmpty());
    }
    @Test void removeByPrefixWorksWithEmbeddedHazelcast() {
        var prefix = "scope:session:s-1:";
        var key1 = prefix + "operation:A:args:1";
        var key2 = prefix + "operation:B:args:2";
        var key3 = "scope:session:s-2:operation:A:args:1";
        store.put(key1, entry(key1, Instant.parse("2026-05-17T12:05:00Z")), new StoreWriteOptions(Duration.ofMinutes(1)));
        store.put(key2, entry(key2, Instant.parse("2026-05-17T12:05:00Z")), new StoreWriteOptions(Duration.ofMinutes(1)));
        store.put(key3, entry(key3, Instant.parse("2026-05-17T12:05:00Z")), new StoreWriteOptions(Duration.ofMinutes(1)));
        store.removeByPrefix(prefix);
        assertTrue(store.get(key1).isEmpty());
        assertTrue(store.get(key2).isEmpty());
        assertTrue(store.get(key3).isPresent());
    }
    @Test void physicalTtlIsAppliedByHazelcastAsCleanupOnly() throws InterruptedException {
        var key = "scope:session:s-ttl:operation:Service.method:args:abc";
        store.put(key, entry(key, Instant.parse("2999-01-01T00:00:00Z")), new StoreWriteOptions(Duration.ofMillis(150)));
        assertTrue(store.get(key).isPresent());
        Thread.sleep(500);
        assertTrue(store.get(key).isEmpty());
    }
    private static StoredInvocationCacheEntry entry(String key, Instant expiresAt) {
        return new StoredInvocationCacheEntry(key, CacheScopeKind.SESSION, "s-1", "test.response", TestResponse.class.getName(), 1, "json", "{\"code\":\"0\",\"description\":\"ok\"}".getBytes(StandardCharsets.UTF_8), Instant.parse("2026-05-17T12:00:00Z"), expiresAt);
    }
}
