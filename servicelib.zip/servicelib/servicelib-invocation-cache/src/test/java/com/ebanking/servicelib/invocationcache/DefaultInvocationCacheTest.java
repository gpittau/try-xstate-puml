package com.ebanking.servicelib.invocationcache;

import static org.junit.jupiter.api.Assertions.*;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.ebanking.servicelib.invocationcache.exception.InvocationCachePayloadTooLargeException;
import com.ebanking.servicelib.invocationcache.jackson.InvocationCacheObjectMapper;
import com.ebanking.servicelib.invocationcache.jackson.JsonPayloadCodec;
import com.ebanking.servicelib.invocationcache.metrics.NoOpInvocationCacheMetrics;
import com.ebanking.servicelib.invocationcache.model.*;

final class DefaultInvocationCacheTest {
    private MutableClock clock;
    private InMemoryInvocationCacheStore store;
    private DefaultInvocationCache cache;
    private JsonPayloadCodec<TestResponse> codec;
    private InvocationCacheDescriptor<TestResponse> descriptor;
    private InvocationCacheKey key;
    @BeforeEach void setUp() {
        clock = MutableClock.utc(Instant.parse("2026-05-17T12:00:00Z"));
        store = new InMemoryInvocationCacheStore(clock);
        cache = new DefaultInvocationCache(store, clock, new NoOpInvocationCacheMetrics());
        codec = new JsonPayloadCodec<>(InvocationCacheObjectMapper.create());
        descriptor = descriptor(512, Duration.ofMinutes(5));
        key = new InvocationCacheKey(new SessionCacheScope("s-1"), "ClientService.getClient", "abc123");
    }
    @Test void putGetReturnsValue() {
        var value = new TestResponse("0", "ok");
        cache.put(key, descriptor, value);
        assertEquals(value, cache.get(key, descriptor).orElseThrow());
    }
    @Test void getMissingReturnsEmpty() { assertTrue(cache.get(key, descriptor).isEmpty()); }
    @Test void expiredEntryReturnsEmptyAndRemoves() {
        cache.put(key, descriptor, new TestResponse("0", "ok"));
        clock.advance(Duration.ofMinutes(6));
        assertTrue(cache.get(key, descriptor).isEmpty());
        assertFalse(store.containsRaw(key.asStoreKey()));
    }
    @Test void putFailsWhenPayloadExceedsMaxBytes() {
        var smallDescriptor = descriptor(4, Duration.ofMinutes(5));
        assertThrows(InvocationCachePayloadTooLargeException.class, () -> cache.put(key, smallDescriptor, new TestResponse("0", "payload too large")));
    }
    @Test void schemaVersionMismatchProducesMissAndRemoves() {
        var payload = codec.serialize(new TestResponse("0", "ok"));
        store.forcePut(key.asStoreKey(), new StoredInvocationCacheEntry(key.asStoreKey(), CacheScopeKind.SESSION, "s-1", descriptor.name(), TestResponse.class.getName(), 99, "json", payload, clock.instant(), clock.instant().plus(Duration.ofMinutes(5))));
        assertTrue(cache.get(key, descriptor).isEmpty());
        assertFalse(store.containsRaw(key.asStoreKey()));
    }
    @Test void getOrComputeDoesNotExecuteSupplierOnHit() {
        var value = new TestResponse("0", "ok");
        cache.put(key, descriptor, value);
        var counter = new AtomicInteger();
        var restored = cache.getOrCompute(key, descriptor, () -> { counter.incrementAndGet(); return new TestResponse("1", "computed"); });
        assertEquals(value, restored);
        assertEquals(0, counter.get());
    }
    @Test void getOrComputeExecutesSupplierOnMiss() {
        var counter = new AtomicInteger();
        var restored = cache.getOrCompute(key, descriptor, () -> { counter.incrementAndGet(); return new TestResponse("1", "computed"); });
        assertEquals(new TestResponse("1", "computed"), restored);
        assertEquals(1, counter.get());
    }
    @Test void evictRemovesEntry() {
        cache.put(key, descriptor, new TestResponse("0", "ok"));
        cache.evict(key);
        assertTrue(cache.get(key, descriptor).isEmpty());
    }
    @Test void evictScopeRemovesEntriesFromScopeOnly() {
        var sameScopeKey = new InvocationCacheKey(new SessionCacheScope("s-1"), "ClientService.getAccounts", "hash-1");
        var otherScopeKey = new InvocationCacheKey(new SessionCacheScope("s-2"), "ClientService.getAccounts", "hash-1");
        cache.put(key, descriptor, new TestResponse("0", "client"));
        cache.put(sameScopeKey, descriptor, new TestResponse("0", "accounts"));
        cache.put(otherScopeKey, descriptor, new TestResponse("0", "other"));
        cache.evictScope(new SessionCacheScope("s-1"));
        assertTrue(cache.get(key, descriptor).isEmpty());
        assertTrue(cache.get(sameScopeKey, descriptor).isEmpty());
        assertTrue(cache.get(otherScopeKey, descriptor).isPresent());
    }
    private InvocationCacheDescriptor<TestResponse> descriptor(int maxBytes, Duration ttl) {
        return new InvocationCacheDescriptor<>("client.response", TestResponse.class, 1, codec, InvocationCachePolicy.query(ttl, maxBytes).withPhysicalRetentionAfterExpiration(Duration.ofMinutes(1)));
    }
}
