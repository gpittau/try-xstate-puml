package com.ebanking.servicelib.invocationcache;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record TestResponse(String code, String description) {}
