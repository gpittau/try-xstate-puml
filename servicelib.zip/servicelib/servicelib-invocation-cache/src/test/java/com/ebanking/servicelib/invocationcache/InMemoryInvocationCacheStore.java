package com.ebanking.servicelib.invocationcache;

import java.time.Clock;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import com.ebanking.servicelib.invocationcache.model.StoreWriteOptions;
import com.ebanking.servicelib.invocationcache.model.StoredInvocationCacheEntry;

public final class InMemoryInvocationCacheStore implements InvocationCacheStore {
    private final Clock clock;
    private final Map<String, ExpiringStoredEntry> entries = new ConcurrentHashMap<>();
    public InMemoryInvocationCacheStore(Clock clock) { this.clock = clock; }
    @Override public void put(String storeKey, StoredInvocationCacheEntry entry, StoreWriteOptions options) { entries.put(storeKey, new ExpiringStoredEntry(entry, clock.instant().plus(options.physicalTtl()))); }
    @Override public Optional<StoredInvocationCacheEntry> get(String storeKey) { return Optional.ofNullable(entries.get(storeKey)).filter(entry -> clock.instant().isBefore(entry.physicalExpiresAt())).map(ExpiringStoredEntry::entry); }
    @Override public void remove(String storeKey) { entries.remove(storeKey); }
    @Override public void removeByPrefix(String prefix) { entries.keySet().removeIf(key -> key.startsWith(prefix)); }
    public boolean containsRaw(String storeKey) { return entries.containsKey(storeKey); }
    public void forcePut(String storeKey, StoredInvocationCacheEntry entry) { entries.put(storeKey, new ExpiringStoredEntry(entry, Instant.parse("2999-01-01T00:00:00Z"))); }
    private record ExpiringStoredEntry(StoredInvocationCacheEntry entry, Instant physicalExpiresAt) {}
}
