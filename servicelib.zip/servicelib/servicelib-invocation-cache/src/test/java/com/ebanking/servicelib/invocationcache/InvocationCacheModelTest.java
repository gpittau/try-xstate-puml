package com.ebanking.servicelib.invocationcache;

import static org.junit.jupiter.api.Assertions.*;
import java.time.Duration;
import org.junit.jupiter.api.Test;
import com.ebanking.servicelib.invocationcache.model.*;

final class InvocationCacheModelTest {
    @Test void physicalKeyIsStable() {
        var key = new InvocationCacheKey(new SessionCacheScope("s-1"), "ClientService.getClient", "abc123");
        assertEquals("scope:session:s-1:operation:ClientService.getClient:args:abc123", key.asStoreKey());
    }
    @Test void policyRejectsInvalidTtl() { assertThrows(IllegalArgumentException.class, () -> new InvocationCachePolicy(InvocationKind.QUERY, Duration.ZERO, Duration.ZERO, 128, false, false, false)); }
    @Test void policyRejectsCommand() { assertThrows(IllegalArgumentException.class, () -> new InvocationCachePolicy(InvocationKind.COMMAND, Duration.ofMinutes(1), Duration.ZERO, 128, false, false, false)); }
    @Test void policyRejectsTechnicalErrorsCaching() { assertThrows(IllegalArgumentException.class, () -> new InvocationCachePolicy(InvocationKind.QUERY, Duration.ofMinutes(1), Duration.ZERO, 128, false, false, true)); }
}
