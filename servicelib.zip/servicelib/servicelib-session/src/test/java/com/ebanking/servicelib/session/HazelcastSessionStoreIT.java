package com.ebanking.servicelib.session;

import static org.junit.jupiter.api.Assertions.*;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.ebanking.servicelib.session.attribute.StoredSessionAttribute;
import com.ebanking.servicelib.session.model.SessionId;
import com.ebanking.servicelib.session.model.SessionMetadata;
import com.ebanking.servicelib.session.model.SessionStatus;
import com.ebanking.servicelib.session.store.HazelcastSessionStore;
import com.hazelcast.config.Config;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;

final class HazelcastSessionStoreIT {
    private HazelcastInstance hazelcast;
    private Clock clock;
    private HazelcastSessionStore store;
    @BeforeEach void setUp() {
        var config = new Config();
        config.setClusterName("servicelib-session-test-" + UUID.randomUUID());
        config.getNetworkConfig().getJoin().getMulticastConfig().setEnabled(false);
        config.getNetworkConfig().getJoin().getTcpIpConfig().setEnabled(false);
        hazelcast = Hazelcast.newHazelcastInstance(config);
        clock = Clock.fixed(Instant.parse("2026-05-17T12:00:00Z"), ZoneOffset.UTC);
        store = new HazelcastSessionStore(hazelcast, clock);
    }
    @AfterEach void tearDown() { hazelcast.shutdown(); }
    @Test void createGetMetadataWorks() {
        var sessionId = new SessionId("s-1");
        var metadata = metadata(sessionId, Instant.parse("2026-05-17T13:00:00Z"));
        store.create(metadata);
        assertEquals(metadata, store.findMetadata(sessionId).orElseThrow());
    }
    @Test void putGetAttributeWorks() {
        var sessionId = new SessionId("s-2");
        var attribute = new StoredSessionAttribute("AUTH_CONTEXT", "com.ebanking.servicelib.session.dto.AuthContext", 1, "json", "{\"userId\":\"u-1\"}".getBytes(java.nio.charset.StandardCharsets.UTF_8), clock.instant());
        store.putAttribute(sessionId, attribute, Instant.parse("2026-05-17T13:00:00Z"));
        assertTrue(store.getAttribute(sessionId, "AUTH_CONTEXT").isPresent());
    }
    @Test void respectsTtl() throws InterruptedException {
        var realClock = Clock.systemUTC();
        var ttlStore = new HazelcastSessionStore(hazelcast, realClock);
        var sessionId = new SessionId("s-ttl");
        var metadata = new SessionMetadata(sessionId, "gabriel", SessionStatus.ACTIVE, realClock.instant(), realClock.instant(), realClock.instant().plusMillis(150));
        ttlStore.create(metadata);
        assertTrue(ttlStore.findMetadata(sessionId).isPresent());
        Thread.sleep(500);
        assertTrue(ttlStore.findMetadata(sessionId).isEmpty());
    }
    private static SessionMetadata metadata(SessionId sessionId, Instant expiresAt) { return new SessionMetadata(sessionId, "gabriel", SessionStatus.ACTIVE, Instant.parse("2026-05-17T12:00:00Z"), Instant.parse("2026-05-17T12:00:00Z"), expiresAt); }
}
