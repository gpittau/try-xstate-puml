package com.ebanking.servicelib.session.store;

import java.time.Clock;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import com.ebanking.servicelib.session.attribute.StoredSessionAttribute;
import com.ebanking.servicelib.session.model.SessionId;
import com.ebanking.servicelib.session.model.SessionMetadata;

public final class InMemorySessionStore implements SessionStore {
    private final Clock clock;
    private final Map<String, SessionMetadata> metadata = new ConcurrentHashMap<>();
    private final Map<String, ExpiringAttribute> attributes = new ConcurrentHashMap<>();
    public InMemorySessionStore(Clock clock) { this.clock = clock; }
    @Override public void create(SessionMetadata sessionMetadata) { metadata.put(metadataKey(sessionMetadata.sessionId()), sessionMetadata); }
    @Override public Optional<SessionMetadata> findMetadata(SessionId sessionId) { return Optional.ofNullable(metadata.get(metadataKey(sessionId))).filter(value -> value.expiresAt().isAfter(clock.instant())); }
    @Override public void save(SessionMetadata sessionMetadata) { metadata.put(metadataKey(sessionMetadata.sessionId()), sessionMetadata); }
    @Override public void putAttribute(SessionId sessionId, StoredSessionAttribute attribute, Instant expiresAt) { attributes.put(attributeKey(sessionId, attribute.name()), new ExpiringAttribute(attribute, expiresAt)); }
    @Override public Optional<StoredSessionAttribute> getAttribute(SessionId sessionId, String attributeName) { return Optional.ofNullable(attributes.get(attributeKey(sessionId, attributeName))).filter(value -> value.expiresAt().isAfter(clock.instant())).map(ExpiringAttribute::attribute); }
    public void forcePutAttribute(SessionId sessionId, StoredSessionAttribute attribute, Instant expiresAt) { putAttribute(sessionId, attribute, expiresAt); }
    private static String metadataKey(SessionId sessionId) { return "session:" + sessionId.value(); }
    private static String attributeKey(SessionId sessionId, String attributeName) { return "session:" + sessionId.value() + ":attribute:" + attributeName; }
    private record ExpiringAttribute(StoredSessionAttribute attribute, Instant expiresAt) {}
}
