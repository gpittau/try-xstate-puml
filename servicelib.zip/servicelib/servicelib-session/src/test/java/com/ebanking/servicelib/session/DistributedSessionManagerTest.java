package com.ebanking.servicelib.session;

import static org.junit.jupiter.api.Assertions.*;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.ebanking.servicelib.session.attribute.SessionAttributes;
import com.ebanking.servicelib.session.attribute.StoredSessionAttribute;
import com.ebanking.servicelib.session.codec.JsonSessionCodec;
import com.ebanking.servicelib.session.codec.SessionObjectMapper;
import com.ebanking.servicelib.session.dto.AuthContext;
import com.ebanking.servicelib.session.dto.ClientContext;
import com.ebanking.servicelib.session.exception.*;
import com.ebanking.servicelib.session.model.LoginRequest;
import com.ebanking.servicelib.session.store.InMemorySessionStore;

final class DistributedSessionManagerTest {
    private Clock clock;
    private InMemorySessionStore store;
    private DistributedSessionManager manager;
    @BeforeEach void setUp() {
        clock = Clock.fixed(Instant.parse("2026-05-17T12:00:00Z"), ZoneOffset.UTC);
        store = new InMemorySessionStore(clock);
        manager = new DistributedSessionManager(store, SessionAttributes.defaultRegistry(), clock, 512);
    }
    @Test void loginCreatesActiveSession() {
        var sessionId = manager.login(loginRequest());
        var metadata = store.findMetadata(sessionId);
        assertTrue(metadata.isPresent());
        assertEquals(sessionId, metadata.orElseThrow().sessionId());
        assertTrue(metadata.orElseThrow().isAliveAt(clock.instant()));
    }
    @Test void typedPutGetWorks() {
        var sessionId = manager.login(loginRequest());
        var value = new AuthContext("u-1", "WEB", List.of("USER", "ADMIN"));
        manager.putAttribute(sessionId, SessionAttributes.AUTH_CONTEXT, value);
        assertEquals(value, manager.getAttribute(sessionId, SessionAttributes.AUTH_CONTEXT).orElseThrow());
    }
    @Test void getMissingAttributeReturnsEmpty() { assertTrue(manager.getAttribute(manager.login(loginRequest()), SessionAttributes.AUTH_CONTEXT).isEmpty()); }
    @Test void logoutInvalidatesSession() {
        var sessionId = manager.login(loginRequest());
        manager.logout(sessionId);
        assertThrows(InactiveSessionException.class, () -> manager.getAttribute(sessionId, SessionAttributes.AUTH_CONTEXT));
    }
    @Test void getAfterLogoutFails() {
        var sessionId = manager.login(loginRequest());
        manager.logout(sessionId);
        assertThrows(InactiveSessionException.class, () -> manager.getAttribute(sessionId, SessionAttributes.CLIENT_CONTEXT));
    }
    @Test void putAfterLogoutFails() {
        var sessionId = manager.login(loginRequest());
        manager.logout(sessionId);
        assertThrows(InactiveSessionException.class, () -> manager.putAttribute(sessionId, SessionAttributes.CLIENT_CONTEXT, new ClientContext("c-1", "RETAIL", "Client One")));
    }
    @Test void payloadTooLargeFails() {
        var sessionId = manager.login(loginRequest());
        var smallManager = new DistributedSessionManager(store, SessionAttributes.defaultRegistry(), clock, 10);
        assertThrows(PayloadTooLargeException.class, () -> smallManager.putAttribute(sessionId, SessionAttributes.CLIENT_CONTEXT, new ClientContext("client-with-long-id", "segment-with-long-name", "display")));
    }
    @Test void incompatibleSchemaVersionFails() {
        var sessionId = manager.login(loginRequest());
        var codec = new JsonSessionCodec<AuthContext>(SessionObjectMapper.create());
        var payload = codec.serialize(new AuthContext("u-1", "WEB", List.of("USER")));
        store.forcePutAttribute(sessionId, new StoredSessionAttribute(SessionAttributes.AUTH_CONTEXT.name(), AuthContext.class.getName(), 99, "json", payload, clock.instant()), Instant.parse("2026-05-17T13:00:00Z"));
        assertThrows(IncompatibleSchemaVersionException.class, () -> manager.getAttribute(sessionId, SessionAttributes.AUTH_CONTEXT));
    }
    @Test void legacyPutGetWorksWithCorrectType() {
        var sessionId = manager.login(loginRequest());
        var value = new ClientContext("c-1", "RETAIL", "Client One");
        manager.putAttribute(sessionId.value(), "CLIENT_CONTEXT", value);
        assertEquals(value, manager.getAttribute(sessionId.value(), "CLIENT_CONTEXT"));
    }
    @Test void legacyPutFailsWithWrongType() {
        var sessionId = manager.login(loginRequest());
        assertThrows(InvalidSessionAttributeTypeException.class, () -> manager.putAttribute(sessionId.value(), "AUTH_CONTEXT", new ClientContext("c-1", "RETAIL", "Client One")));
    }
    @Test void legacyGetReturnsNullWhenMissing() { assertNull(manager.getAttribute(manager.login(loginRequest()).value(), "AUTH_CONTEXT")); }
    @Test void legacyFailsWithUnknownAttribute() {
        var sessionId = manager.login(loginRequest());
        assertThrows(UnknownSessionAttributeException.class, () -> manager.getAttribute(sessionId.value(), "UNKNOWN"));
    }
    private static LoginRequest loginRequest() { return new LoginRequest("gabriel", Instant.parse("2026-05-17T13:00:00Z"), Map.of("channel", "WEB")); }
}
