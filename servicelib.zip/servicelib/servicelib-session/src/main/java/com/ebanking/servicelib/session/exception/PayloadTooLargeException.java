package com.ebanking.servicelib.session.exception;

public final class PayloadTooLargeException extends SessionException {
    public PayloadTooLargeException(String attributeName, int actualBytes, int maxBytes) {
        super("Payload too large for attribute '%s'. Actual: %d bytes, max: %d bytes".formatted(attributeName, actualBytes, maxBytes));
    }
}
