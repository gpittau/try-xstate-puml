package com.ebanking.servicelib.session.exception;

import com.ebanking.servicelib.session.model.SessionId;

public final class SessionNotFoundException extends SessionException {
    public SessionNotFoundException(SessionId sessionId) { super("Session not found: " + sessionId); }
}
