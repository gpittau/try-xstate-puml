package com.ebanking.servicelib.session;

import java.util.Optional;
import com.ebanking.servicelib.session.attribute.SessionAttribute;
import com.ebanking.servicelib.session.model.LoginRequest;
import com.ebanking.servicelib.session.model.SessionId;

public interface SessionManager {
    SessionId login(LoginRequest request);
    void logout(SessionId sessionId);
    <T> void putAttribute(SessionId sessionId, SessionAttribute<T> attribute, T value);
    <T> Optional<T> getAttribute(SessionId sessionId, SessionAttribute<T> attribute);
    @Deprecated(forRemoval = false) void putAttribute(String sessionId, String name, Object value);
    @Deprecated(forRemoval = false) Object getAttribute(String sessionId, String name);
}
