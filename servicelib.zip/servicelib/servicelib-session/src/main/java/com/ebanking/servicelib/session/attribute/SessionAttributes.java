package com.ebanking.servicelib.session.attribute;

import com.ebanking.servicelib.session.codec.JsonSessionCodec;
import com.ebanking.servicelib.session.codec.SessionObjectMapper;
import com.ebanking.servicelib.session.dto.AuthContext;
import com.ebanking.servicelib.session.dto.ClientContext;

public final class SessionAttributes {
    private static final JsonSessionCodec<AuthContext> AUTH_CONTEXT_CODEC = new JsonSessionCodec<>(SessionObjectMapper.create());
    private static final JsonSessionCodec<ClientContext> CLIENT_CONTEXT_CODEC = new JsonSessionCodec<>(SessionObjectMapper.create());
    public static final SessionAttribute<AuthContext> AUTH_CONTEXT = new SessionAttribute<>("AUTH_CONTEXT", AuthContext.class, 1, AUTH_CONTEXT_CODEC);
    public static final SessionAttribute<ClientContext> CLIENT_CONTEXT = new SessionAttribute<>("CLIENT_CONTEXT", ClientContext.class, 1, CLIENT_CONTEXT_CODEC);
    private SessionAttributes() {}
    public static SessionAttributeRegistry defaultRegistry() { return SimpleSessionAttributeRegistry.of(AUTH_CONTEXT, CLIENT_CONTEXT); }
}
