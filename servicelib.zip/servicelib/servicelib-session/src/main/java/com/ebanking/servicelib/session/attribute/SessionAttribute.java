package com.ebanking.servicelib.session.attribute;

import java.util.Objects;
import com.ebanking.servicelib.session.codec.SessionCodec;

public record SessionAttribute<T>(String name, Class<T> type, int schemaVersion, SessionCodec<T> codec) {
    public SessionAttribute {
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(codec, "codec");
        if (name.isBlank()) throw new IllegalArgumentException("name must not be blank");
        if (schemaVersion <= 0) throw new IllegalArgumentException("schemaVersion must be positive");
    }
}
