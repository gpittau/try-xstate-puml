package com.ebanking.servicelib.session.exception;

public final class InvalidSessionAttributeTypeException extends SessionException {
    public InvalidSessionAttributeTypeException(String name, Class<?> expectedType, Class<?> actualType) {
        super("Invalid type for session attribute '%s'. Expected: %s, actual: %s".formatted(name, expectedType.getName(), actualType == null ? "null" : actualType.getName()));
    }
}
