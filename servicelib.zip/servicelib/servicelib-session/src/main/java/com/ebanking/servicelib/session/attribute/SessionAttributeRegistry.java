package com.ebanking.servicelib.session.attribute;

import java.util.Optional;
import com.ebanking.servicelib.session.exception.UnknownSessionAttributeException;

public interface SessionAttributeRegistry {
    Optional<SessionAttribute<?>> find(String name);
    default SessionAttribute<?> required(String name) { return find(name).orElseThrow(() -> new UnknownSessionAttributeException(name)); }
}
