package com.ebanking.servicelib.session.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record ClientContext(String clientId, String segment, String displayName) {}
