package com.ebanking.servicelib.session.codec;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

public final class SessionObjectMapper {
    private SessionObjectMapper() {}
    public static ObjectMapper create() {
        return new ObjectMapper().registerModule(new Jdk8Module()).registerModule(new JavaTimeModule()).disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }
}
