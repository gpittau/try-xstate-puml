package com.ebanking.servicelib.session.exception;

import com.ebanking.servicelib.session.model.SessionId;

public final class InactiveSessionException extends SessionException {
    public InactiveSessionException(SessionId sessionId) { super("Session is not active: " + sessionId); }
}
