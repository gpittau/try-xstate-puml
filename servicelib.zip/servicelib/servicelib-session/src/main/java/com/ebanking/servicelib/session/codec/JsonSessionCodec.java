package com.ebanking.servicelib.session.codec;

import java.io.IOException;
import java.util.Objects;
import com.ebanking.servicelib.session.exception.SessionSerializationException;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class JsonSessionCodec<T> implements SessionCodec<T> {
    private final ObjectMapper objectMapper;
    public JsonSessionCodec(ObjectMapper objectMapper) { this.objectMapper = Objects.requireNonNull(objectMapper, "objectMapper"); }
    @Override public String name() { return "json"; }
    @Override public byte[] serialize(T value) {
        try { return objectMapper.writeValueAsBytes(value); }
        catch (IOException e) { throw new SessionSerializationException("Could not serialize session attribute", e); }
    }
    @Override public T deserialize(byte[] payload, Class<T> type) {
        try { return objectMapper.readValue(payload, type); }
        catch (IOException e) { throw new SessionSerializationException("Could not deserialize session attribute as " + type.getName(), e); }
    }
}
