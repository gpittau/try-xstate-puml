package com.ebanking.servicelib.session.codec;

public interface SessionCodec<T> {
    String name();
    byte[] serialize(T value);
    T deserialize(byte[] payload, Class<T> type);
}
