package com.ebanking.servicelib.session.store;

import java.time.Instant;
import java.util.Optional;
import com.ebanking.servicelib.session.attribute.StoredSessionAttribute;
import com.ebanking.servicelib.session.model.SessionId;
import com.ebanking.servicelib.session.model.SessionMetadata;

public interface SessionStore {
    void create(SessionMetadata metadata);
    Optional<SessionMetadata> findMetadata(SessionId sessionId);
    void save(SessionMetadata metadata);
    void putAttribute(SessionId sessionId, StoredSessionAttribute attribute, Instant expiresAt);
    Optional<StoredSessionAttribute> getAttribute(SessionId sessionId, String attributeName);
}
