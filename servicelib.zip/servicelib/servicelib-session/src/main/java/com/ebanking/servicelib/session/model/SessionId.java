package com.ebanking.servicelib.session.model;

import java.util.Objects;

public record SessionId(String value) {
    public SessionId {
        Objects.requireNonNull(value, "value");
        if (value.isBlank()) throw new IllegalArgumentException("sessionId must not be blank");
    }
    @Override public String toString() { return value; }
}
