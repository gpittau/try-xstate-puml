package com.ebanking.servicelib.session.attribute;

import java.io.Serial;
import java.io.Serializable;
import java.time.Instant;
import java.util.Arrays;
import java.util.Objects;

public record StoredSessionAttribute(String name, String javaType, int schemaVersion, String codec, byte[] payload, Instant storedAt) implements Serializable {
    @Serial private static final long serialVersionUID = 1L;
    public StoredSessionAttribute {
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(javaType, "javaType");
        Objects.requireNonNull(codec, "codec");
        Objects.requireNonNull(payload, "payload");
        Objects.requireNonNull(storedAt, "storedAt");
        payload = Arrays.copyOf(payload, payload.length);
    }
    @Override public byte[] payload() { return Arrays.copyOf(payload, payload.length); }
}
