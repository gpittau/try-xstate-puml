package com.ebanking.servicelib.session.exception;

public final class SessionSerializationException extends SessionException {
    public SessionSerializationException(String message, Throwable cause) { super(message, cause); }
}
