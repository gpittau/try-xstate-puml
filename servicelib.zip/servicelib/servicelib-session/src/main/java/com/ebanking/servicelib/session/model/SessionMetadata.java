package com.ebanking.servicelib.session.model;

import java.io.Serial;
import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

public record SessionMetadata(SessionId sessionId, String principal, SessionStatus status, Instant createdAt, Instant updatedAt, Instant expiresAt) implements Serializable {
    @Serial private static final long serialVersionUID = 1L;
    public SessionMetadata {
        Objects.requireNonNull(sessionId, "sessionId");
        Objects.requireNonNull(principal, "principal");
        Objects.requireNonNull(status, "status");
        Objects.requireNonNull(createdAt, "createdAt");
        Objects.requireNonNull(updatedAt, "updatedAt");
        Objects.requireNonNull(expiresAt, "expiresAt");
    }
    public boolean isAliveAt(Instant now) { return status == SessionStatus.ACTIVE && now.isBefore(expiresAt); }
    public SessionMetadata withStatus(SessionStatus newStatus, Instant now) { return new SessionMetadata(sessionId, principal, newStatus, createdAt, now, expiresAt); }
}
