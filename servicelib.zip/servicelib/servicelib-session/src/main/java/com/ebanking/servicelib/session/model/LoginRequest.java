package com.ebanking.servicelib.session.model;

import java.time.Instant;
import java.util.Map;
import java.util.Objects;

public record LoginRequest(String principal, Instant expiresAt, Map<String, String> tags) {
    public LoginRequest {
        Objects.requireNonNull(principal, "principal");
        Objects.requireNonNull(expiresAt, "expiresAt");
        tags = Map.copyOf(Objects.requireNonNull(tags, "tags"));
        if (principal.isBlank()) throw new IllegalArgumentException("principal must not be blank");
    }
    public static LoginRequest of(String principal, Instant expiresAt) { return new LoginRequest(principal, expiresAt, Map.of()); }
}
