package com.ebanking.servicelib.session.model;

public enum SessionStatus { ACTIVE, LOGGED_OUT }
