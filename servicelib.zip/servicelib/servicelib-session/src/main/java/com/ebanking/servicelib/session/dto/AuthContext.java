package com.ebanking.servicelib.session.dto;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record AuthContext(String userId, String channel, List<String> roles) {
    public AuthContext { roles = List.copyOf(roles); }
}
