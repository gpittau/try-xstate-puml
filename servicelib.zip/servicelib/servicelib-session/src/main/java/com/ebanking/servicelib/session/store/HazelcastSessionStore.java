package com.ebanking.servicelib.session.store;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import com.ebanking.servicelib.session.attribute.StoredSessionAttribute;
import com.ebanking.servicelib.session.model.SessionId;
import com.ebanking.servicelib.session.model.SessionMetadata;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;

public final class HazelcastSessionStore implements SessionStore {
    public static final String METADATA_MAP = "sessions.metadata";
    public static final String ATTRIBUTES_MAP = "sessions.attributes";
    private final IMap<String, SessionMetadata> metadataMap;
    private final IMap<String, StoredSessionAttribute> attributesMap;
    private final Clock clock;
    public HazelcastSessionStore(HazelcastInstance hazelcastInstance, Clock clock) {
        Objects.requireNonNull(hazelcastInstance, "hazelcastInstance");
        this.metadataMap = hazelcastInstance.getMap(METADATA_MAP);
        this.attributesMap = hazelcastInstance.getMap(ATTRIBUTES_MAP);
        this.clock = Objects.requireNonNull(clock, "clock");
    }
    @Override public void create(SessionMetadata metadata) { metadataMap.set(metadataKey(metadata.sessionId()), metadata, ttlMillis(metadata.expiresAt()), TimeUnit.MILLISECONDS); }
    @Override public Optional<SessionMetadata> findMetadata(SessionId sessionId) { return Optional.ofNullable(metadataMap.get(metadataKey(sessionId))); }
    @Override public void save(SessionMetadata metadata) { metadataMap.set(metadataKey(metadata.sessionId()), metadata, ttlMillis(metadata.expiresAt()), TimeUnit.MILLISECONDS); }
    @Override public void putAttribute(SessionId sessionId, StoredSessionAttribute attribute, Instant expiresAt) { attributesMap.set(attributeKey(sessionId, attribute.name()), attribute, ttlMillis(expiresAt), TimeUnit.MILLISECONDS); }
    @Override public Optional<StoredSessionAttribute> getAttribute(SessionId sessionId, String attributeName) { return Optional.ofNullable(attributesMap.get(attributeKey(sessionId, attributeName))); }
    public static String metadataKey(SessionId sessionId) { return "session:" + sessionId.value(); }
    public static String attributeKey(SessionId sessionId, String attributeName) { return "session:" + sessionId.value() + ":attribute:" + attributeName; }
    private long ttlMillis(Instant expiresAt) { return Math.max(1L, Duration.between(clock.instant(), expiresAt).toMillis()); }
}
