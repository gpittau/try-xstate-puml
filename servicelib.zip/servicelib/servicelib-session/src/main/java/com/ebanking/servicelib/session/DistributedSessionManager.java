package com.ebanking.servicelib.session;

import java.time.Clock;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import com.ebanking.servicelib.session.attribute.SessionAttribute;
import com.ebanking.servicelib.session.attribute.SessionAttributeRegistry;
import com.ebanking.servicelib.session.attribute.StoredSessionAttribute;
import com.ebanking.servicelib.session.exception.InactiveSessionException;
import com.ebanking.servicelib.session.exception.IncompatibleSchemaVersionException;
import com.ebanking.servicelib.session.exception.InvalidSessionAttributeTypeException;
import com.ebanking.servicelib.session.exception.PayloadTooLargeException;
import com.ebanking.servicelib.session.exception.SessionNotFoundException;
import com.ebanking.servicelib.session.model.LoginRequest;
import com.ebanking.servicelib.session.model.SessionId;
import com.ebanking.servicelib.session.model.SessionMetadata;
import com.ebanking.servicelib.session.model.SessionStatus;
import com.ebanking.servicelib.session.store.SessionStore;

public final class DistributedSessionManager implements SessionManager {
    private final SessionStore store;
    private final SessionAttributeRegistry registry;
    private final Clock clock;
    private final int maxPayloadBytes;

    public DistributedSessionManager(SessionStore store, SessionAttributeRegistry registry, Clock clock, int maxPayloadBytes) {
        this.store = Objects.requireNonNull(store, "store");
        this.registry = Objects.requireNonNull(registry, "registry");
        this.clock = Objects.requireNonNull(clock, "clock");
        this.maxPayloadBytes = maxPayloadBytes;
        if (maxPayloadBytes <= 0) throw new IllegalArgumentException("maxPayloadBytes must be positive");
    }

    @Override public SessionId login(LoginRequest request) {
        Objects.requireNonNull(request, "request");
        var now = clock.instant();
        var sessionId = new SessionId(UUID.randomUUID().toString());
        var metadata = new SessionMetadata(sessionId, request.principal(), SessionStatus.ACTIVE, now, now, request.expiresAt());
        store.create(metadata);
        return sessionId;
    }

    @Override public void logout(SessionId sessionId) {
        var metadata = activeMetadata(sessionId);
        store.save(metadata.withStatus(SessionStatus.LOGGED_OUT, clock.instant()));
    }

    @Override public <T> void putAttribute(SessionId sessionId, SessionAttribute<T> attribute, T value) {
        Objects.requireNonNull(attribute, "attribute");
        Objects.requireNonNull(value, "value");
        var metadata = activeMetadata(sessionId);
        var payload = attribute.codec().serialize(value);
        if (payload.length > maxPayloadBytes) throw new PayloadTooLargeException(attribute.name(), payload.length, maxPayloadBytes);
        var stored = new StoredSessionAttribute(attribute.name(), attribute.type().getName(), attribute.schemaVersion(), attribute.codec().name(), payload, clock.instant());
        store.putAttribute(metadata.sessionId(), stored, metadata.expiresAt());
    }

    @Override public <T> Optional<T> getAttribute(SessionId sessionId, SessionAttribute<T> attribute) {
        Objects.requireNonNull(attribute, "attribute");
        var metadata = activeMetadata(sessionId);
        return store.getAttribute(metadata.sessionId(), attribute.name()).map(stored -> decodeStoredAttribute(attribute, stored));
    }

    @Override @Deprecated(forRemoval = false) public void putAttribute(String sessionId, String name, Object value) {
        var attribute = registry.required(name);
        if (!attribute.type().isInstance(value)) {
            throw new InvalidSessionAttributeTypeException(name, attribute.type(), value == null ? null : value.getClass());
        }
        putLegacy(new SessionId(sessionId), attribute, value);
    }

    @Override @Deprecated(forRemoval = false) public Object getAttribute(String sessionId, String name) {
        var attribute = registry.required(name);
        return getLegacy(new SessionId(sessionId), attribute).orElse(null);
    }

    private SessionMetadata activeMetadata(SessionId sessionId) {
        Objects.requireNonNull(sessionId, "sessionId");
        var metadata = store.findMetadata(sessionId).orElseThrow(() -> new SessionNotFoundException(sessionId));
        if (metadata.status() != SessionStatus.ACTIVE || !metadata.isAliveAt(clock.instant())) throw new InactiveSessionException(sessionId);
        return metadata;
    }

    private <T> T decodeStoredAttribute(SessionAttribute<T> attribute, StoredSessionAttribute stored) {
        if (stored.schemaVersion() != attribute.schemaVersion()) throw new IncompatibleSchemaVersionException(attribute.name(), attribute.schemaVersion(), stored.schemaVersion());
        return attribute.codec().deserialize(stored.payload(), attribute.type());
    }

    private <T> void putLegacy(SessionId sessionId, SessionAttribute<T> attribute, Object value) {
        putAttribute(sessionId, attribute, attribute.type().cast(value));
    }

    private <T> Optional<T> getLegacy(SessionId sessionId, SessionAttribute<T> attribute) {
        return getAttribute(sessionId, attribute);
    }
}
