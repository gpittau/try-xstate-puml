package com.ebanking.servicelib.session.exception;

public final class UnknownSessionAttributeException extends SessionException {
    public UnknownSessionAttributeException(String name) { super("Unknown session attribute: " + name); }
}
