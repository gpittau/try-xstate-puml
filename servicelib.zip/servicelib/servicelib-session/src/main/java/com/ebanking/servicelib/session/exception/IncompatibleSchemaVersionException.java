package com.ebanking.servicelib.session.exception;

public final class IncompatibleSchemaVersionException extends SessionException {
    public IncompatibleSchemaVersionException(String attributeName, int expectedVersion, int actualVersion) {
        super("Incompatible schemaVersion for attribute '%s'. Expected: %d, actual: %d".formatted(attributeName, expectedVersion, actualVersion));
    }
}
