package com.ebanking.servicelib.session.attribute;

import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public final class SimpleSessionAttributeRegistry implements SessionAttributeRegistry {
    private final Map<String, SessionAttribute<?>> attributes;
    public SimpleSessionAttributeRegistry(Collection<SessionAttribute<?>> attributes) {
        Objects.requireNonNull(attributes, "attributes");
        this.attributes = attributes.stream().collect(Collectors.toUnmodifiableMap(SessionAttribute::name, Function.identity()));
    }
    public static SimpleSessionAttributeRegistry of(SessionAttribute<?>... attributes) { return new SimpleSessionAttributeRegistry(java.util.List.of(attributes)); }
    @Override public Optional<SessionAttribute<?>> find(String name) { return Optional.ofNullable(attributes.get(name)); }
}
