# ServiceLib

Java 21 multi-module library for session management and service invocation caching.

## Modules

- `servicelib-session`: legacy-compatible `SessionManager` backed by typed session attributes, governed JSON serialization, and Hazelcast.
- `servicelib-invocation-cache`: invocation cache decoupled from `SessionManager`, backed by a dedicated Hazelcast map named `invocation.cache`.

## Requirements

- Java 21
- Maven
- Preview features enabled by Maven compiler and Surefire configuration

## Build

```bash
mvn clean test
```

## Design boundary

```text
SessionManager
  owns login/logout/session attributes
  uses sessions.metadata
  uses sessions.attributes

InvocationCache
  owns invocation result caching
  uses invocation.cache
  supports SessionCacheScope, UserCacheScope and GlobalCacheScope
  does not depend on SessionManager
```
